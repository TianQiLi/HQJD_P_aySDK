//
//  SFWebKitConfig.h
//  SFWebKit
//
//  Created by dongkui on 2019/11/10.
//  Copyright © 2019年 dongkui. All rights reserved.
//

#import <UIKit/UIKit.h>

#ifndef _JDPAY_WEBKIT_CONFIG_H_
#define _JDPAY_WEBKIT_CONFIG_H_

// #define [Module]Using[Feature]    on(1)/off(0) // comments

#endif /* _JDPAY_WEBKIT_CONFIG_H_ */
