//
//  JDPayAvailability.h
//  JDPayFoundation
//
//  Created by dongkui on 11/07/2017.
//  Copyright © 2017 JD. All rights reserved.
//

#ifndef _JDPAY_AVAILABILITY_H_
#define _JDPAY_AVAILABILITY_H_

#define JDPAY_DEPRECATED(_module, _version, ...) __deprecated_msg("first deprecated in "_module" "_version" - "__VA_ARGS__)

#endif // _JDPAY_AVAILABILITY_H_
