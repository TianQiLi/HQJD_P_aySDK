//
//  OCUITableView.h
//
//  Created by dongkui on 8/28/16.
//  Copyright (c) 2016 dongkui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/**
 Custom table view, which supports quick response for UIControl in the table view
 */
@interface JDPayUITableView : UITableView
@end
