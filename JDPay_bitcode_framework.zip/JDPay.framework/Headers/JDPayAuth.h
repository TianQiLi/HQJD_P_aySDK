//
//  JDPayAuth.h
//  JDPayAuth
//
//  Created by dongkui on 18/11/5.
//  Copyright © 2018年 JD. All rights reserved.
//

#import <JDPayAuth/JDPayAuthSDK.h>
